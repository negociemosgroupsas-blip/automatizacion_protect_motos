/* PROTECT MOTOS — Módulo Renovaciones: ENVIAR COTIZACIÓN + panel «Cotizaciones de renovación».
   Es un archivo aparte: solo suma. Usa las reglas de assets/cotizador_core.js y el conector del CRM (crm-4).
   Nada se envía solo: el WhatsApp se abre únicamente cuando la persona lo confirma. */
(function(w){
  'use strict';
  var d = document;
  var LS = function(k){ try{ return localStorage.getItem(k)||''; }catch(e){ return ''; } };
  var LSset = function(k,v){ try{ localStorage.setItem(k,v); }catch(e){} };
  function esc(t){ return String(t==null?'':t).replace(/[&<>"]/g,function(c){ return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]; }); }
  function cop(n){ return '$'+Math.round(Number(n)||0).toLocaleString('es-CO'); }
  function num(v){ return Number(String(v||'').replace(/[^0-9]/g,''))||0; }
  function $(id){ return d.getElementById(id); }

  // ---------- Conector (CRM) ----------
  var cnt = 0, TIPO = '';   // '' = renovaciones (Cobros) · 'nueva' = cotizaciones de clientes nuevos (módulo Cotizador)
  function llamar(params){
    if(TIPO) params.tipo = TIPO;
    return new Promise(function(ok, mal){
      var url = LS('pm_crm_url'), tok = LS('pm_crm_token')||'PM-CRM-2026';
      if(!url){ mal(new Error('Falta la URL del conector del CRM (pestaña Conexiones).')); return; }
      cnt++;
      var cb = 'pm_cr_'+Date.now()+'_'+cnt, s = d.createElement('script'), fin = false;
      var t = setTimeout(function(){ if(fin) return; fin=true; limpiar(); mal(new Error('El conector no respondió a tiempo.')); }, 25000);
      function limpiar(){ clearTimeout(t); try{ delete w[cb]; }catch(e){ w[cb]=undefined; } if(s.parentNode) s.parentNode.removeChild(s); }
      w[cb] = function(r){ if(fin) return; fin=true; limpiar(); ok(r); };
      s.onerror = function(){ if(fin) return; fin=true; limpiar(); mal(new Error('No se pudo contactar el conector del CRM.')); };
      var q = 'token='+encodeURIComponent(tok)+'&callback='+cb;
      Object.keys(params).forEach(function(k){ q += '&'+encodeURIComponent(k)+'='+encodeURIComponent(params[k]); });
      s.src = url + (url.indexOf('?')<0?'?':'&') + q;
      d.body.appendChild(s);
    }).then(function(r){
      if(!r || r.ok===false){
        var m = (r&&r.error)||'Respuesta inválida.';
        if(/Acción no disponible/.test(m)) m = 'El conector del CRM todavía no tiene la versión crm-4. Pega el código nuevo (conectores/crm/Codigo_crm.gs) y publica «Nueva versión».';
        throw new Error(m);
      }
      return r;
    });
  }

  // ---------- Estilos y ventanas ----------
  function css(){
    if($('pmcr_css')) return;
    var s = d.createElement('style'); s.id='pmcr_css';
    s.textContent =
      '.pmcr-fondo{position:fixed;inset:0;background:rgba(10,20,40,.55);z-index:9999;display:none;align-items:flex-start;justify-content:center;overflow:auto;padding:24px 12px}'+
      '.pmcr-fondo.on{display:flex}'+
      '.pmcr-caja{background:#fff;border-radius:14px;max-width:640px;width:100%;padding:20px 22px;box-shadow:0 12px 40px rgba(0,0,0,.3);font-family:inherit;color:#13223f}'+
      '.pmcr-caja h3{margin:0 0 4px;font-size:1.1rem}.pmcr-sub{color:#667;font-size:.85rem;margin:0 0 12px}'+
      '.pmcr-g{display:grid;grid-template-columns:1fr 1fr;gap:10px 12px}@media(max-width:560px){.pmcr-g{grid-template-columns:1fr}}'+
      '.pmcr-g label{display:flex;flex-direction:column;font-size:.85rem;font-weight:700;gap:3px}.pmcr-g .ancho{grid-column:1/-1}'+
      '.pmcr-g input,.pmcr-g select,.pmcr-g textarea{border:1px solid #cfd6e4;border-radius:8px;padding:8px 10px;font:inherit;font-weight:400;font-size:.9rem}'+
      '.pmcr-g input[readonly]{background:#f1f4f9}'+
      '.pmcr-cuadro{background:#f4f7fc;border:1px solid #dbe3f1;border-radius:10px;padding:10px 12px;margin:12px 0;font-size:.86rem;line-height:1.5}'+
      '.pmcr-msg{width:100%;min-height:200px;border:1px solid #cfd6e4;border-radius:8px;padding:10px;font:inherit;font-size:.86rem;box-sizing:border-box}'+
      '.pmcr-bar{display:flex;gap:8px;flex-wrap:wrap;margin-top:12px}'+
      '.pmcr-b{border:0;border-radius:8px;padding:9px 14px;font-weight:700;font-size:.85rem;cursor:pointer;background:#13223f;color:#fff}'+
      '.pmcr-b.v{background:#1f9d55}.pmcr-b.g{background:#e3e8f2;color:#13223f}.pmcr-b.r{background:#c0392b}.pmcr-b.o{background:#e0a800;color:#13223f}.pmcr-b:disabled{opacity:.5;cursor:default}'+
      '.pmcr-st{font-size:.85rem;margin-top:8px;min-height:1.2em}.pmcr-st.mal{color:#b3261e}.pmcr-st.bien{color:#0b6b2b}'+
      '.pmcr-tiles{display:grid;grid-template-columns:repeat(auto-fill,minmax(130px,1fr));gap:10px;margin-bottom:12px}'+
      '.pmcr-t{background:#f4f7fc;border:1px solid #dbe3f1;border-radius:10px;padding:10px}.pmcr-t b{display:block;font-size:1.3rem}.pmcr-t span{font-size:.85rem;color:#556}'+
      '.pmcr-tw{overflow:auto}.pmcr-tw table{border-collapse:collapse;width:100%;font-size:.85rem}.pmcr-tw th,.pmcr-tw td{border-bottom:1px solid #e4e9f2;padding:6px 8px;text-align:left;white-space:nowrap}.pmcr-tw th{background:#13223f;color:#fff}'+
      '.pmcr-e{display:inline-block;border-radius:999px;padding:2px 9px;font-size:.85rem;font-weight:700}.pmcr-e.p{background:#fff3c4;color:#7a5b00}.pmcr-e.a{background:#d7f5df;color:#0b6b2b}.pmcr-e.n{background:#fad4d4;color:#9b1c1c}';
    d.head.appendChild(s);
  }
  function ventana(id, html){
    css();
    var f = $(id);
    if(!f){ f = d.createElement('div'); f.id=id; f.className='pmcr-fondo'; d.body.appendChild(f); }
    f.innerHTML = '<div class="pmcr-caja">'+html+'</div>';
    f.classList.add('on');
    return f;
  }
  function cerrar(id){ var f=$(id); if(f) f.classList.remove('on'); }
  function numWA(c){ var x=String(c||'').replace(/\D/g,''); return (x.indexOf('57')===0 && x.length>10) ? x : '57'+x; }

  // ---------- Mensaje ----------
  function lineaFin(o, plazo){
    return o.primera!==o.resto ? ('1ª cuota '+cop(o.primera)+' y '+(plazo-1)+' cuotas de '+cop(o.resto)+' (total '+cop(o.total)+')') : (plazo+' cuotas de '+cop(o.cuota)+' (total '+cop(o.total)+')');
  }
  function mensaje(q){
    var m = '¡Hola, '+q.nombre+'! 😊\nTe escribimos de Protect Motos.\n\n'+
      'Queremos ayudarte a renovar la garantía de tu moto '+(q.moto?(q.moto+' '):'')+'de placa '+q.placa+(q.aseguradora&&q.aseguradora!=='Protect Motos'?' con '+q.aseguradora:'')+'.\n\n'+
      '💛 *Opción 1 · Hurto o pérdida total'+(q.aseguradora==='Protect Motos'?' (cubre el 80 %)':'')+'*\n'+
      '• De contado: '+cop(q.op1.contado)+'\n'+
      '• Financiado a '+q.plazo+' meses: '+lineaFin(q.op1,q.plazo)+'\n\n'+
      '💙 *Opción 2 · Hurto / pérdida total + responsabilidad civil + asistencias*\n'+
      '• De contado: '+cop(q.op2.contado)+'\n'+
      '• Financiado a '+q.plazo+' meses: '+lineaFin(q.op2,q.plazo)+'\n'+
      '🎁 *¡De regalo!* Plan de salud por llevar la Opción 2, para el titular y 2 beneficiarios más: '+planTxt()+'\n\n'+
      'Te adjuntamos la cotización con todas las coberturas. ¿Quieres que renovemos tu garantía? Respóndenos y lo dejamos listo hoy mismo 💙';
    return m;
  }

  // ---------- Formulario: ENVIAR COTIZACIÓN ----------
  var cur = null;
  var ASEG = ['Protect Motos','Sura','Otra'];
  /* Precios FIJOS de renovación por moto (12 meses). Formato por línea:
     palabra de la moto | contado op.1 | cuota op.1 | contado op.2 | 1ª cuota op.2 | cuota restante op.2   (op.2 = con RC y AP) */
  var FIJOS_DEF = ['ADX | 887940 | 92493 | 1087797 | 292351 | 92493'];
  function leerFijos(){ var g = LS('pm_ren_fijos'); if(g){ try{ var a = JSON.parse(g); if(a && a.length) return a; }catch(e){} } return FIJOS_DEF.slice(); }
  function buscarFijo(moto){
    var m = String(moto||'').toUpperCase(), L = leerFijos();
    for(var i=0;i<L.length;i++){
      var c = String(L[i]).split('|').map(function(x){ return x.trim(); }); if(c.length<6) continue;
      var kw = c[0].toUpperCase(), n = c.slice(1,6).map(num);
      if(kw && m.indexOf(kw)>=0 && n[0]>0 && n[1]>0 && n[2]>0 && n[3]>0 && n[4]>0) return { palabra:c[0], c1:n[0], q1:n[1], c2:n[2], p2:n[3], q2:n[4] };
    }
    return null;
  }
  function abrir(c){
    cur = { c:c, guardada:null };
    var f = ventana('pmcr_fcot',
      '<h3>Enviar cotización de renovación</h3><p class="pmcr-sub">Datos del cliente tomados del sistema. Elige con qué cotizador calculas (factura y Fasecolda, o valor de la moto), elige la aseguradora y confirma.</p>'+
      '<div class="pmcr-g">'+
      '<label>Nombre<input id="pmcr_nom" value="'+esc(c.cliente)+'"></label>'+
      '<label>Cédula<input id="pmcr_ced" value="'+esc(c.cedula||'')+'"></label>'+
      '<label>Placa<input id="pmcr_pla" value="'+esc(c.placa)+'"></label>'+
      '<label>Marca / referencia<input id="pmcr_moto" placeholder="cargando…"></label>'+
      '<label style="grid-column:1/-1">¿Con qué cotizador calculo?<select id="pmcr_met"><option value="fas">Cotizador de renovación: con la factura y el valor de Fasecolda</option><option value="val">Cotizador de Contratos: con el valor de la moto</option></select></label>'+
      '<label id="pmcr_lfac">Valor factura del año anterior<input id="pmcr_fac" inputmode="numeric" placeholder="$"></label>'+
      '<label id="pmcr_lfas">Valor Fasecolda actual<input id="pmcr_fas" inputmode="numeric" placeholder="$ (escríbelo)"></label>'+
      '<label id="pmcr_lgar">Valor a garantizar (−10 %, el menor)<input id="pmcr_gar" readonly></label>'+
      '<label id="pmcr_lval" style="display:none">Valor de la moto (como en Contratos)<input id="pmcr_val" inputmode="numeric" placeholder="$ 11.499.000"></label>'+
      '<label>Plazo financiado<select id="pmcr_plz"><option value="3">3 meses</option><option value="6">6 meses</option><option value="12" selected>12 meses</option></select></label>'+
      '<label>¿Con qué aseguradora va?<select id="pmcr_ase">'+ASEG.map(function(a){return '<option>'+a+'</option>';}).join('')+'</select></label>'+
      '<label id="pmcr_otral" style="display:none">Nombre de la aseguradora<input id="pmcr_otra" placeholder="Ej.: Mundial"></label>'+
      '</div>'+
      '<div id="pmcr_man" style="display:none"><p class="pmcr-sub" style="margin:10px 0 4px"><b>Valores de la aseguradora</b> (no se calculan solos: escríbelos como te los dio la aseguradora)</p>'+
      '<div class="pmcr-g">'+
      '<label>Opción 1 · valor de contado<input id="pmcr_m1c" inputmode="numeric" placeholder="$"></label><label>Opción 1 · valor de cada cuota<input id="pmcr_m1q" inputmode="numeric" placeholder="$"></label>'+
      '<label>Opción 2 · valor de contado<input id="pmcr_m2c" inputmode="numeric" placeholder="$"></label><label>Opción 2 · valor de cada cuota<input id="pmcr_m2q" inputmode="numeric" placeholder="$"></label>'+
      '</div></div>'+
      '<div id="pmcr_fijobox" class="pmcr-cuadro" style="display:none;background:#fff6d6;border-color:#f0cf6a"><label style="display:flex;flex-direction:row;gap:8px;align-items:flex-start;font-weight:700;font-size:.85rem"><input type="checkbox" id="pmcr_fijo" checked style="margin-top:3px"><span id="pmcr_fijotxt"></span></label></div>'+
      '<div class="pmcr-cuadro" id="pmcr_res">Escribe la factura y el valor de Fasecolda para calcular.</div>'+
      '<details style="margin:6px 0 10px"><summary style="cursor:pointer;font-weight:700;font-size:.85rem">Precios fijos de renovación por moto (ej. ADX)</summary>'+
      '<label style="display:flex;flex-direction:column;font-size:.85rem;gap:3px;margin-top:8px">Una moto por línea: palabra | contado opción 1 | cuota opción 1 | contado opción 2 | primera cuota opción 2 | cuota restante opción 2<textarea id="pmcr_fij" rows="3" style="border:1px solid #cfd6e4;border-radius:8px;padding:8px 10px;font:inherit;font-size:.85rem"></textarea></label><p class="pmcr-sub" style="margin:4px 0 0">Si el nombre de la moto contiene esa palabra, la cotización usa estos valores (12 meses) y no hace falta escribir el Fasecolda. <a href="#" id="pmcr_fijrest">Restaurar</a></p></details>'+
      '<details style="margin:6px 0 10px"><summary style="cursor:pointer;font-weight:700;font-size:.85rem">Coberturas que salen en el PDF (puedes editarlas)</summary>'+
      '<div class="pmcr-g" style="margin-top:8px"><label>Opción 1 · una cobertura por línea<textarea id="pmcr_cb1" rows="6"></textarea></label><label>Opción 2 · una cobertura por línea<textarea id="pmcr_cb2" rows="6"></textarea></label></div>'+
      '<label style="display:flex;flex-direction:column;font-size:.85rem;gap:3px;margin-top:8px;font-weight:700">🎁 Plan de salud que se regala con la Opción 2 (un beneficio por línea; sale en la franja de regalo)<textarea id="pmcr_plan" rows="4" style="border:1px solid #cfd6e4;border-radius:8px;padding:8px 10px;font:inherit;font-size:.85rem;font-weight:400" placeholder="Un beneficio por línea"></textarea></label>'+
      '<p class="pmcr-sub" style="margin:4px 0 0">Una línea entre guiones, como <code>— Asistencias —</code>, crea un título dentro de la lista. Se guardan para la próxima cotización con esta aseguradora. <a href="#" id="pmcr_rest">Restaurar las originales</a></p></details>'+
      '<label style="font-size:.85rem;font-weight:700">Mensaje de WhatsApp (puedes editarlo)</label>'+
      '<textarea class="pmcr-msg" id="pmcr_txt"></textarea>'+
      '<div class="pmcr-st" id="pmcr_st"></div>'+
      '<div class="pmcr-bar">'+
      '<button class="pmcr-b o" id="pmcr_pdf">📄 Cotización en PDF</button>'+
      '<button class="pmcr-b o" id="pmcr_img">🖼️ Cotización en imagen</button>'+
      '<button class="pmcr-b" id="pmcr_gua">Guardar cotización</button>'+
      '<button class="pmcr-b g" id="pmcr_cop">Copiar mensaje</button>'+
      '<button class="pmcr-b v" id="pmcr_wa">Abrir WhatsApp</button>'+
      '<button class="pmcr-b g" id="pmcr_cer">Cerrar</button></div>'+
      '<p class="pmcr-sub" style="margin-top:8px">Para enviarla: descarga el PDF o la imagen, abre WhatsApp con el botón verde y adjunta el archivo. Nada se envía solo.</p>');
    var fac=$('pmcr_fac'), fas=$('pmcr_fas');
    try{ if(localStorage.getItem('pm_cot_met')==='val') $('pmcr_met').value='val'; }catch(e){}
    ['pmcr_nom','pmcr_ced','pmcr_pla','pmcr_moto','pmcr_met','pmcr_val','pmcr_fac','pmcr_fas','pmcr_plz','pmcr_ase','pmcr_otra','pmcr_m1c','pmcr_m1q','pmcr_m2c','pmcr_m2q'].forEach(function(id){ $(id).addEventListener('input', recalcular); $(id).addEventListener('change', recalcular); });
    $('pmcr_plan').value = PMCotDoc.planSalud().join('\n'); $('pmcr_plan').addEventListener('change', function(){ PMCotDoc.guardarPlanSalud(lineasCob('pmcr_plan')); }); $('pmcr_plan').addEventListener('input', recalcular);
    $('pmcr_fij').value = leerFijos().join('\n');
    $('pmcr_fij').addEventListener('change', function(){ var L=$('pmcr_fij').value.split('\n').map(function(x){return x.trim();}).filter(Boolean); LSset('pm_ren_fijos', JSON.stringify(L)); recalcular(); });
    $('pmcr_fijrest').onclick = function(e){ e.preventDefault(); try{ localStorage.removeItem('pm_ren_fijos'); }catch(x){} $('pmcr_fij').value = FIJOS_DEF.join('\n'); recalcular(); };
    $('pmcr_fijo').addEventListener('change', recalcular);
    $('pmcr_ase').addEventListener('change', function(){ cargarCob(); });
    $('pmcr_otra').addEventListener('change', function(){ cargarCob(); });
    ['pmcr_cb1','pmcr_cb2'].forEach(function(id){ $(id).addEventListener('change', function(){
      var a=aseguradora(); if(a==='Otra'&&!$('pmcr_otra').value.trim()) return;
      PMCotDoc.guardarCoberturas(a, id==='pmcr_cb1'?'op1':'op2', lineasCob(id)); }); });
    $('pmcr_rest').onclick = function(e){ e.preventDefault(); PMCotDoc.restaurarCoberturas(aseguradora()); cargarCob(); };
    $('pmcr_txt').addEventListener('input', function(){ cur.editado = true; });
    $('pmcr_cer').onclick = function(){ cerrar('pmcr_fcot'); };
    $('pmcr_gua').onclick = function(){ guardar(false); };
    $('pmcr_cop').onclick = copiar;
    $('pmcr_wa').onclick = abrirWA;
    $('pmcr_pdf').onclick = function(){ hacerDoc('pdf'); };
    $('pmcr_img').onclick = function(){ hacerDoc('img'); };
    cargarCob();
    llamar({action:'cotRen_moto', contrato:c.contrato}).then(function(r){
      if(r.encontrado){
        if(r.cliente) $('pmcr_nom').value = r.cliente;      // nombre completo tal como está en la hoja Protect
        if(r.placa) $('pmcr_pla').value = r.placa;          // placa de la hoja Protect (si la hay)
        if(!$('pmcr_ced').value) $('pmcr_ced').value = r.cedula||'';
        $('pmcr_moto').value = [r.marca, r.referencia].filter(Boolean).join(' ');
        if(r.valorMoto>0) fac.value = r.valorMoto.toLocaleString('es-CO');
        cur.celular = r.celular || c.celular;
        var rec = ''; try{ rec = (JSON.parse(LS('pm_cotren_fase')||'{}'))[(r.referencia||'').toUpperCase()]||''; }catch(e){}
        if(rec && !fas.value) fas.value = Number(rec).toLocaleString('es-CO');
      } else { $('pmcr_moto').placeholder = 'escríbela'; setSt('No se encontró la moto en Protect: completa los datos a mano.', 'mal'); }
      recalcular();
    }).catch(function(e){ $('pmcr_moto').placeholder='escríbela'; setSt(e.message,'mal'); recalcular(); });
    recalcular();
  }
  function metodo(){ var e=$('pmcr_met'); return e&&e.value==='val' ? 'val' : 'fas'; }
  function aplicarMetodo(){
    var v = metodo()==='val';
    ['pmcr_lfac','pmcr_lfas','pmcr_lgar'].forEach(function(id){ $(id).style.display = v ? 'none' : ''; });
    $('pmcr_lval').style.display = v ? '' : 'none';
    try{ localStorage.setItem('pm_cot_met', v?'val':'fas'); }catch(e){}
  }
  function planTxt(){ var l=lineasCob('pmcr_plan'); return l.length ? l.join(' · ') : 'consulta a tu asesor sus beneficios'; }
  function aseguradora(){ var a=$('pmcr_ase').value; return a==='Otra' ? ($('pmcr_otra').value.trim()||'Otra') : a; }
  function lineasCob(id){ return $(id).value.split('\n').map(function(t){return t.trim();}).filter(Boolean); }
  function cargarCob(){
    $('pmcr_otral').style.display = $('pmcr_ase').value==='Otra' ? '' : 'none';
    $('pmcr_man').style.display = $('pmcr_ase').value==='Protect Motos' ? 'none' : '';
    var a = aseguradora();
    $('pmcr_cb1').value = PMCotDoc.coberturas(a,'op1').join('\n');
    $('pmcr_cb2').value = PMCotDoc.coberturas(a,'op2').join('\n');
    recalcular();
  }
  function setSt(t,k){ var e=$('pmcr_st'); if(e){ e.textContent=t; e.className='pmcr-st '+(k||''); } }
  function leer(){
    var fac=num($('pmcr_fac').value), fas=num($('pmcr_fas').value), plz=Number($('pmcr_plz').value), ase=aseguradora(), propia=$('pmcr_ase').value==='Protect Motos';
    var met = metodo(), gar = met==='val' ? num($('pmcr_val').value) : PMCot.valorAGarantizar(fac, fas), O = PMCot.opciones(gar, plz), op1, op2;
    var fijoDef = (propia && plz===12 && met==='fas') ? buscarFijo($('pmcr_moto').value) : null, usaFijo = !!(fijoDef && $('pmcr_fijo') && $('pmcr_fijo').checked);
    if(usaFijo){
      op1 = {contado:fijoDef.c1, cuota:fijoDef.q1, total:fijoDef.q1*12, primera:fijoDef.q1, resto:fijoDef.q1};
      op2 = {contado:fijoDef.c2, cuota:fijoDef.q2, total:fijoDef.p2+11*fijoDef.q2, primera:fijoDef.p2, resto:fijoDef.q2};
    } else if(propia){ op1 = O?O.op1:{contado:0,cuota:0,total:0,primera:0,resto:0}; op2 = O?O.op2:{contado:0,cuota:0,total:0,primera:0,resto:0}; }
    else{
      var m = function(a,b){ var c=num($(a).value), q=num($(b).value); return {contado:c, cuota:q, total:q*plz, primera:q, resto:q}; };
      op1 = m('pmcr_m1c','pmcr_m1q'); op2 = m('pmcr_m2c','pmcr_m2q');
    }
    return { nombre:$('pmcr_nom').value.trim(), cedula:$('pmcr_ced').value.trim(), placa:$('pmcr_pla').value.trim(), moto:$('pmcr_moto').value.trim(),
      metodo:met, factura:(met==='val'?gar:fac), fasecolda:(met==='val'?0:fas), garantizar:gar, plazo:plz, aseguradora:ase, propia:propia, op1:op1, op2:op2, cubre:O?O.cubre:0, rc:(O?O.rc:PMCot.RC_DEFECTO), ap:(O?O.ap:PMCot.AP_DEFECTO),
      contado:op1.contado, financiado:op1.total, cuota:op1.cuota, contrato:cur.c.contrato, fijoDef:fijoDef, usaFijo:usaFijo, listo:(gar>0||usaFijo) };
  }
  function resumenOp(o, plz){ return 'contado <b>'+cop(o.contado)+'</b> · '+plz+' cuotas'+(o.primera!==o.resto?' (1ª de <b>'+cop(o.primera)+'</b>, luego <b>'+cop(o.resto)+'</b>)':' de <b>'+cop(o.cuota)+'</b>')+' · total <b>'+cop(o.total)+'</b>'; }
  function recalcular(){
    if(!cur) return;
    cur.guardada = null; // si cambian valores, se guardaría como una cotización nueva
    aplicarMetodo();
    var q = leer(), fd = (q.propia && q.plazo===12 && q.metodo==='fas') ? buscarFijo($('pmcr_moto').value) : null;
    $('pmcr_fijobox').style.display = fd ? '' : 'none';
    if(fd) $('pmcr_fijotxt').textContent = 'Esta moto tiene PRECIO FIJO de renovación ('+fd.palabra.toUpperCase()+'): se usan esos valores y no el Fasecolda. Desmarca si quieres calcularla normal.';
    $('pmcr_gar').value = q.usaFijo ? 'No aplica (precio fijo)' : (q.garantizar ? cop(q.garantizar) : '');
    if(!q.listo){ $('pmcr_res').innerHTML = q.metodo==='val' ? 'Escribe el <b>valor de la moto</b> para calcular.' : 'Escribe la factura y el valor de Fasecolda para calcular.'; return; }
    var a = q.factura>0 ? Math.round(q.factura/1.1) : 0, b = q.fasecolda>0 ? Math.round(q.fasecolda/1.1) : 0;
    $('pmcr_res').innerHTML = (q.metodo==='val' ? 'Valor de la moto <b>'+cop(q.garantizar)+'</b> · contado 7,5 % · financiado '+(q.plazo===3?9:q.plazo===6?10:12)+' %'+(q.propia?' · cubre el 80 %: <b>'+cop(q.cubre)+'</b>':'') : q.usaFijo ? '<b>Precio fijo de renovación ('+esc(q.fijoDef.palabra.toUpperCase())+')</b>' : 'Factura −10 %: <b>'+(a?cop(a):'—')+'</b> · Fasecolda −10 %: <b>'+(b?cop(b):'—')+'</b> → valor a garantizar <b>'+cop(q.garantizar)+'</b>'+(q.propia?' · cubre el 80 %: <b>'+cop(q.cubre)+'</b>':''))+'<br>'+
      '<b>Opción 1</b> (hurto o pérdida total): '+resumenOp(q.op1,q.plazo)+'<br><b>Opción 2</b> (+ RC + asistencias): '+resumenOp(q.op2,q.plazo)+(q.propia?'':'<br><i>Valores escritos a mano para '+esc(q.aseguradora)+'.</i>');
    if(!cur.editado) $('pmcr_txt').value = mensaje(q);
  }
  function datosDoc(q){
    return { id:cur.guardada||'', nombre:q.nombre, placa:q.placa, moto:q.moto, aseguradora:q.aseguradora, plazo:q.plazo, garantizar:q.garantizar,
      op1:q.op1, op2:q.op2, cubre:q.cubre, rc:q.rc, ap:q.ap, cob1:lineasCob('pmcr_cb1'), cob2:lineasCob('pmcr_cb2'), salud:lineasCob('pmcr_plan') };
  }
  function hacerDoc(tipo){
    var q = leer();
    if(!q.nombre){ setSt('Falta el nombre.','mal'); return; }
    if(!q.listo){ setSt(metodo()==='val'?'Escribe el valor de la moto antes.':'Escribe la factura y/o el valor de Fasecolda antes.','mal'); return; }
    if(!(q.op1.contado>0) || !(q.op2.contado>0)){ setSt('Faltan los valores de contado de las dos opciones.','mal'); return; }
    var d1 = datosDoc(q);
    if(tipo==='pdf'){
      if(!PMCotDoc.imprimir(d1)) setSt('El navegador bloqueó la ventana. Permite las ventanas emergentes de este sistema y vuelve a pulsar.','mal');
      else setSt('Se abrió la cotización: elige «Guardar como PDF» como impresora y guarda el archivo.','bien');
      return;
    }
    setSt('Creando la imagen…');
    PMCotDoc.png(d1).then(function(blob){
      var a = d.createElement('a'); a.href = URL.createObjectURL(blob); a.download = 'Cotizacion_'+(q.placa||'moto')+'_'+q.nombre.split(' ')[0]+'.png'; d.body.appendChild(a); a.click(); a.remove();
      setSt('Imagen descargada. Adjúntala en el chat de WhatsApp.','bien');
    }).catch(function(e){ setSt('No se pudo crear la imagen ('+e.message+'). Usa el PDF.','mal'); });
  }
  function guardar(silencioso){
    var q = leer();
    if(!q.nombre) { setSt('Falta el nombre.','mal'); return Promise.reject(); }
    if(!q.listo){ setSt(metodo()==='val'?'Escribe el valor de la moto antes de guardar.':'Escribe la factura y/o el valor de Fasecolda antes de guardar.','mal'); return Promise.reject(); }
    if(!(q.op1.contado>0) || !(q.op2.contado>0)){ setSt('Faltan los valores de contado de las dos opciones.','mal'); return Promise.reject(); }
    if(cur.guardada){ setSt('Esta cotización ya quedó guardada ('+cur.guardada+').','bien'); return Promise.resolve(cur.guardada); }
    setSt('Guardando…'); $('pmcr_gua').disabled = true;
    var obs = 'Cotizado con '+q.aseguradora+(q.usaFijo?' · PRECIO FIJO '+q.fijoDef.palabra.toUpperCase():'')+' · Op.1 hurto/pérdida total: contado '+cop(q.op1.contado)+' / '+q.plazo+' cuotas, total '+cop(q.op1.total)+' · Op.2 (+RC +asistencias): contado '+cop(q.op2.contado)+' / '+q.plazo+' cuotas, total '+cop(q.op2.total);
    return llamar({action:'cotRen_guardar', nombre:q.nombre, cedula:q.cedula, placa:q.placa, moto:q.moto, factura:q.factura, fasecolda:q.fasecolda,
      contado:q.contado, financiado:q.financiado, plazo:q.plazo, contrato:q.contrato, obs:obs}).then(function(r){
      cur.guardada = r.id; setSt('Cotización guardada: '+r.id+' (estado Pendiente).','bien');
      try{ var k=(q.moto.split(' ').slice(1).join(' ')||q.moto).toUpperCase(); var db=JSON.parse(LS('pm_cotren_fase')||'{}'); if(q.fasecolda>0) db[k]=q.fasecolda; LSset('pm_cotren_fase',JSON.stringify(db)); }catch(e){}
      $('pmcr_gua').disabled = false; if(w.PMCotRen && w.PMCotRen.panelRefrescar) w.PMCotRen.panelRefrescar();
      return r.id;
    }).catch(function(e){ setSt(e.message,'mal'); $('pmcr_gua').disabled=false; throw e; });
  }
  function copiar(){
    var t = $('pmcr_txt').value;
    function ok(){ setSt('Mensaje copiado. Pégalo en WhatsApp.','bien'); }
    if(navigator.clipboard && navigator.clipboard.writeText){ navigator.clipboard.writeText(t).then(ok, function(){ $('pmcr_txt').select(); d.execCommand('copy'); ok(); }); }
    else { $('pmcr_txt').select(); d.execCommand('copy'); ok(); }
  }
  function abrirWA(){
    var q = leer();
    if(!q.listo){ setSt(metodo()==='val'?'Primero escribe el valor de la moto.':'Primero escribe la factura y el valor de Fasecolda.','mal'); return; }
    if(!(q.op1.contado>0) || !(q.op2.contado>0)){ setSt('Faltan los valores de contado de las dos opciones.','mal'); return; }
    var cel = cur.celular || cur.c.celular;
    if(!w.confirm('¿Abrir WhatsApp con el mensaje para '+q.nombre+'?\n\nEl mensaje NO se envía solo: tú lo revisas, adjuntas el PDF o la imagen y le das enviar. Si la cotización no está guardada, se guardará ahora como Pendiente.')) return;
    var abrir2 = function(){ w.open('https://wa.me/'+numWA(cel)+'?text='+encodeURIComponent($('pmcr_txt').value), '_blank'); };
    if(cur.guardada){ abrir2(); return; }
    guardar().then(abrir2, function(){ /* el error ya se mostró; no se abre WhatsApp */ });
  }

  // ---------- Panel ----------
  var DATOS = [];
  function panelRefrescar(){
    var cont = $('pmcr_panel'); if(!cont) return Promise.resolve();
    cont.querySelector('.pmcr-cuerpo').innerHTML = '<p class="pmcr-sub">Cargando cotizaciones…</p>';
    return llamar({action:'cotRen_listar'}).then(function(r){ DATOS = r.cotizaciones||[]; pintar(); })
      .catch(function(e){ cont.querySelector('.pmcr-cuerpo').innerHTML = '<p class="pmcr-st mal">'+esc(e.message)+'</p>'; });
  }
  function pintar(){
    var cont = $('pmcr_panel'); css();
    var f = $('pmcr_filtro') ? $('pmcr_filtro').value : 'todos', b = $('pmcr_busca') ? $('pmcr_busca').value.toLowerCase() : '';
    var tot = DATOS.length, pen = 0, ace = 0, no = 0, con = 0, fin = 0, rc = 0, ap = 0, ase = {};
    DATOS.forEach(function(x){
      if(x.estado==='Pendiente') pen++; else if(x.estado==='Aceptó renovación'){ ace++; if(x.forma==='Contado') con++; else if(x.forma==='Financiado') fin++;
        if(x.rc==='Sí') rc++; if(x.ap==='Sí') ap++; var a=x.aseguradora||'Sin dato'; ase[a]=(ase[a]||0)+1; } else if(x.estado==='No aceptó renovación') no++;
    });
    var resp = ace+no, conv = tot ? Math.round(ace*100/tot) : 0;
    var tiles = [['Total cotizaciones',tot],['Pendientes',pen],['Aceptaron',ace],['No aceptaron',no],['% conversión',conv+' %'],['Contado',con],['Financiado',fin],['Con RC',rc],['Con AP',ap]];
    var h = '<div class="pmcr-tiles">'+tiles.map(function(t){ return '<div class="pmcr-t"><b>'+t[1]+'</b><span>'+t[0]+'</span></div>'; }).join('')+'</div>';
    var ks = Object.keys(ase); if(ks.length) h += '<p class="pmcr-sub"><b>Por aseguradora (aceptadas):</b> '+ks.map(function(k){ return esc(k)+': '+ase[k]; }).join(' · ')+'</p>';
    var lista = DATOS.filter(function(x){
      if(f==='pend' && x.estado!=='Pendiente') return false; if(f==='ace' && x.estado!=='Aceptó renovación') return false; if(f==='no' && x.estado!=='No aceptó renovación') return false;
      return !b || (x.nombre+' '+x.placa+' '+x.cedula+' '+x.id).toLowerCase().indexOf(b)>=0;
    }).reverse();
    h += '<div class="pmcr-tw"><table><thead><tr><th>ID</th><th>Fecha</th><th>Cliente</th><th>Placa</th><th>Moto</th><th>Contado</th><th>Financiado</th><th>Plazo</th><th>Estado</th><th>Aseguradora</th><th>Valor final</th><th>Acciones</th></tr></thead><tbody>';
    lista.forEach(function(x){
      var cl = x.estado==='Pendiente'?'p':x.estado==='Aceptó renovación'?'a':'n';
      h += '<tr><td>'+esc(x.id)+'</td><td>'+esc(x.fecha)+'</td><td>'+esc(x.nombre)+'</td><td>'+esc(x.placa)+'</td><td>'+esc(x.moto)+'</td><td>'+cop(x.contado)+'</td><td>'+cop(x.financiado)+'</td><td>'+(x.plazo||'')+'</td>'+
        '<td><span class="pmcr-e '+cl+'">'+esc(TIPO?x.estado.replace(' renovación',''):x.estado)+'</span></td><td>'+esc(x.aseguradora)+'</td><td>'+(x.valorFinal?cop(x.valorFinal):'')+'</td><td>'+
        (x.estado==='Pendiente' ? '<button class="pmcr-b v" data-a="ace" data-id="'+esc(x.id)+'">Aceptó</button> <button class="pmcr-b r" data-a="no" data-id="'+esc(x.id)+'">No aceptó</button>' : '')+'</td></tr>';
    });
    h += '</tbody></table></div>'; if(!lista.length) h += '<p class="pmcr-sub">No hay cotizaciones en esta vista.</p>';
    cont.querySelector('.pmcr-cuerpo').innerHTML = h;
    Array.prototype.forEach.call(cont.querySelectorAll('button[data-a]'), function(bt){
      bt.onclick = function(){ var x = DATOS.filter(function(y){ return y.id===bt.getAttribute('data-id'); })[0]; if(x) (bt.getAttribute('data-a')==='ace' ? formAcepto : formNoAcepto)(x); };
    });
  }
  function iniciarPanel(cont){
    css();
    cont.innerHTML = '<div id="pmcr_panel"><div class="pmcr-g" style="grid-template-columns:auto auto auto 1fr;align-items:end;margin-bottom:10px">'+
      '<label>Ver<select id="pmcr_filtro"><option value="todos">Todas</option><option value="pend">Pendientes</option><option value="ace">Aceptaron</option><option value="no">No aceptaron</option></select></label>'+
      '<label>Buscar<input id="pmcr_busca" type="search" placeholder="nombre, placa, cédula o ID"></label>'+
      '<button class="pmcr-b g" id="pmcr_ref">Actualizar</button></div><div class="pmcr-cuerpo"></div></div>';
    $('pmcr_filtro').onchange = pintar; $('pmcr_busca').oninput = pintar; $('pmcr_ref').onclick = panelRefrescar;
    return panelRefrescar();
  }

  // ---------- Aceptó / No aceptó ----------
  function formAcepto(x){
    ventana('pmcr_facep',
      '<h3>'+(TIPO?'Aceptó la cotización':'Aceptó la renovación')+'</h3><p class="pmcr-sub">'+esc(x.nombre)+' · '+esc(x.placa)+' · '+esc(x.id)+'</p>'+
      '<div class="pmcr-g">'+
      '<label>Aseguradora<select id="pa_ase"><option>Protect Motos</option><option>OMS</option><option>Sura</option><option value="__o">Otra…</option></select></label>'+
      '<label id="pa_otl" style="display:none">¿Cuál?<input id="pa_ot"></label>'+
      '<label>Forma de pago<select id="pa_for"><option value="Contado">Contado</option><option value="Financiado">Financiado</option></select></label>'+
      '<label id="pa_plzl" style="display:none">Plazo (meses)<select id="pa_plz"><option>3</option><option>6</option><option selected>12</option></select></label>'+
      '<label>¿Lleva RC?<select id="pa_rc"><option>No</option><option>Sí</option></select></label>'+
      '<label>¿Lleva AP?<select id="pa_ap"><option>No</option><option>Sí</option></select></label>'+
      '<label>Valor final contratado<input id="pa_val" inputmode="numeric" placeholder="$"></label>'+
      '<label class="ancho">Observaciones<textarea id="pa_obs" rows="2"></textarea></label></div>'+
      '<div class="pmcr-st" id="pa_st"></div><div class="pmcr-bar"><button class="pmcr-b v" id="pa_ok">Guardar aceptación</button><button class="pmcr-b g" id="pa_x">Cancelar</button></div>');
    $('pa_val').value = (x.financiado||x.contado) ? Number(x.contado||0).toLocaleString('es-CO') : '';
    $('pa_ase').onchange = function(){ $('pa_otl').style.display = this.value==='__o' ? '' : 'none'; };
    $('pa_for').onchange = function(){ var fi=this.value==='Financiado'; $('pa_plzl').style.display = fi?'':'none'; $('pa_val').value = (fi?x.financiado:x.contado) ? Number(fi?x.financiado:x.contado).toLocaleString('es-CO') : ''; };
    $('pa_x').onclick = function(){ cerrar('pmcr_facep'); };
    $('pa_ok').onclick = function(){
      var ase = $('pa_ase').value==='__o' ? $('pa_ot').value.trim() : $('pa_ase').value, st=$('pa_st');
      if(!ase){ st.textContent='Escribe la aseguradora.'; st.className='pmcr-st mal'; return; }
      var fo = $('pa_for').value, val = num($('pa_val').value);
      if(!(val>0)){ st.textContent='Escribe el valor final contratado.'; st.className='pmcr-st mal'; return; }
      if(!w.confirm('¿Confirmas que '+x.nombre+' ACEPTÓ la renovación con '+ase+' ('+fo+', '+cop(val)+')?')) return;
      $('pa_ok').disabled = true; st.textContent='Guardando…'; st.className='pmcr-st';
      llamar({action:'cotRen_estado', id:x.id, estado:'Aceptó renovación', aseguradora:ase, forma:fo, plazo:fo==='Financiado'?$('pa_plz').value:'', rc:$('pa_rc').value, ap:$('pa_ap').value, valorFinal:val, obs:$('pa_obs').value})
        .then(function(){ cerrar('pmcr_facep'); return panelRefrescar(); })
        .catch(function(e){ st.textContent=e.message; st.className='pmcr-st mal'; $('pa_ok').disabled=false; });
    };
  }
  function formNoAcepto(x){
    ventana('pmcr_fno',
      '<h3>'+(TIPO?'No aceptó la cotización':'No aceptó la renovación')+'</h3><p class="pmcr-sub">'+esc(x.nombre)+' · '+esc(x.placa)+' · '+esc(x.id)+'</p>'+
      '<div class="pmcr-g"><label class="ancho">Motivo (opcional)<textarea id="pn_obs" rows="2" placeholder="Ej.: precio, ya renovó en otra parte, vendió la moto…"></textarea></label></div>'+
      '<div class="pmcr-st" id="pn_st"></div><div class="pmcr-bar"><button class="pmcr-b r" id="pn_ok">Guardar</button><button class="pmcr-b g" id="pn_x">Cancelar</button></div>');
    $('pn_x').onclick = function(){ cerrar('pmcr_fno'); };
    $('pn_ok').onclick = function(){
      if(!w.confirm('¿Confirmas que '+x.nombre+' NO aceptó la renovación?')) return;
      $('pn_ok').disabled = true;
      llamar({action:'cotRen_estado', id:x.id, estado:'No aceptó renovación', obs:$('pn_obs').value})
        .then(function(){ cerrar('pmcr_fno'); return panelRefrescar(); })
        .catch(function(e){ $('pn_st').textContent=e.message; $('pn_st').className='pmcr-st mal'; $('pn_ok').disabled=false; });
    };
  }

  w.PMCotRen = { setTipo:function(t){ TIPO = t||''; }, abrir:abrir, iniciarPanel:iniciarPanel, panelRefrescar:panelRefrescar, _mensaje:mensaje };
})(window);
