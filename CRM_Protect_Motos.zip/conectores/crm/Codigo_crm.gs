/**
 * PROTECT MOTOS — Conector del CRM (lectura + comisiones)
 *
 * Proyecto de Apps Script NUEVO e independiente: no modifica ni reemplaza el conector de Cobros,
 * ni el de Conciliación, ni el de Contratos. Lee la hoja y entrega los datos al Inicio del CRM
 * (gráficas, alertas, buscador y comisiones). Lo ÚNICO que escribe son las pestañas nuevas «Comisiones_Config» y «Comisiones_Historico»
 * (decisiones, observaciones e informes de comisiones guardados). Nunca modifica Protect ni Pagos.
 *
 * Publicar como Aplicación web:  Ejecutar como: Yo  ·  Quién tiene acceso: Cualquier usuario.
 */

// ==================== CONFIGURACIÓN ====================
var TOKEN = 'PM-CRM-2026';   // si lo cambias, cámbialo igual en la pestaña «Conexiones» del CRM (se pega junto a la URL)
var SHEET_ID = '1WMR0VhNg6apQa5BPg4bFoRbMqJNdQQ9f3UdlA2fKb04';
var HOJA_SEGUIMIENTO = 'Protect';
var HOJA_PAGOS = 'Pagos';
var FILA_INICIO_DATOS = 2; // fila 1 = encabezados

var COL = {
  ASESOR: 2,
  CEDULA: 5,
  CLIENTE: 8,
  FECHA: 11,        // Fecha de firma
  FIN: 12,           // Fecha de vencimiento de la póliza
  PLACA: 13,
  CONTRATO: 14,      // N° de contrato (clave única)
  VALOR_PROTECT: 15, // Valor total financiado
  VALOR_CUOTA: 17,
  PLAZO: 18,
  COMISION: 19,      // Valor de la comisión (columna S)
  FORMA: 20,         // CONTADO | FINANCIADO
  FECHA_NAC: 6,      // Fecha de nacimiento del cliente (columna F)
  EDAD: 7,           // Edad del cliente al firmar (columna G)
  MES: 9,            // Mes del contrato (columna I)
  ANIO: 10,          // Año del contrato (columna J)
  RC: 21,            // Responsabilidad Civil: SI | NO (columna U)
  AP: 23,            // Asistencias: SI | NO (columna W)
  CELULAR: 31,
  CORREO: 32,
  DIRECCION: 33,
  ESTADO_CLIENTE: 44 // ACTIVO | CANCELADO | FINALIZADO (columna AR)
};

// ==================== PUNTO DE ENTRADA ====================
function doGet(e) {
  var params = (e && e.parameter) ? e.parameter : {};
  var salida;
  try {
    if (params.token !== TOKEN) {
      salida = { ok: false, error: 'Token inválido.' };
    } else {
      var accion = params.action || 'datos';
      if (accion === 'datos') {
        salida = accionDatos();
      } else if (accion === 'guardarClave') {
        salida = accionGuardarClave(params);
      } else if (accion === 'listarReportes') {
        salida = accionListarReportes();
      } else if (accion === 'verReporte') {
        salida = accionVerReporte(params);
      } else if (accion === 'banco_leer') {
        salida = accionBancoLeer(params);
      } else if (accion === 'mundial_guardar') {
        salida = accionMundialGuardar(params);
      } else if (accion === 'mundial_leer') {
        salida = accionMundialLeer(params);
      } else if (accion === 'banco_anotar') {
        salida = accionBancoAnotar(params);
      } else if (accion === 'erp_protect') {
        salida = accionErpProtect();
      } else if (accion === 'renov_gestiones') {
        salida = accionRenovGestiones();
      } else if (accion === 'cotRen_moto') {
        salida = accionCotRenMoto(params);
      } else if (accion === 'cotRen_listar') {
        salida = accionCotRenListar(params);
      } else if (accion === 'cotRen_guardar') {
        salida = accionCotRenGuardar(params);
      } else if (accion === 'cotRen_estado') {
        salida = accionCotRenEstado(params);
      } else if (accion === 'ping') {
        salida = { ok: true, mensaje: 'Conector del CRM activo', version: 'crm-12' };
      } else {
        salida = { ok: false, error: 'Acción no disponible: ' + accion };
      }
    }
  } catch (err) {
    salida = { ok: false, error: 'Error en el servidor: ' + err.message };
  }
  return responder(salida, params.callback);
}

// Solo para guardar informes de comisiones en el histórico (el contenido es grande y no cabe en una URL).
function doPost(e) {
  var salida;
  try {
    var body = (e && e.postData && e.postData.contents) ? JSON.parse(e.postData.contents) : {};
    if (body.token !== TOKEN) salida = { ok: false, error: 'Token inválido.' };
    else if (body.action === 'guardarReporte') salida = accionGuardarReporte(body);
    else salida = { ok: false, error: 'Acción desconocida: ' + body.action };
  } catch (err) {
    salida = { ok: false, error: 'Error en el servidor: ' + err.message };
  }
  return responder(salida, null);
}

function responder(objeto, callback) {
  var json = JSON.stringify(objeto);
  if (callback) {
    return ContentService
      .createTextOutput(callback + '(' + json + ')')
      .setMimeType(ContentService.MimeType.JAVASCRIPT);
  }
  return ContentService
    .createTextOutput(json)
    .setMimeType(ContentService.MimeType.JSON);
}

// ==================== ACCIÓN: DATOS ====================
function accionDatos() {
  var ss = SpreadsheetApp.openById(SHEET_ID);
  var hojaSeg = hojaSeguimiento(ss);
  var hojaPagos = ss.getSheetByName(HOJA_PAGOS);
  return { ok: true, contratos: leerContratos(hojaSeg), pagos: leerPagos(hojaPagos), gestiones: [], comisionesCfg: leerConfigComisiones(ss) };
}

// Número de columna con ese título en la fila 1 (0 si no existe). Las columnas de cancelación las crea el conector de Cobros.
function columnaPorEncabezado(hoja, titulo) {
  var ult = Math.max(hoja.getLastColumn(), 1);
  var enc = hoja.getRange(1, 1, 1, ult).getValues()[0], b = String(titulo).trim().toLowerCase();
  for (var i = 0; i < enc.length; i++) { if (String(enc[i] || '').trim().toLowerCase() === b) return i + 1; }
  return 0;
}

function leerContratos(hoja) {
  var ultimaFila = hoja.getLastRow();
  if (ultimaFila < FILA_INICIO_DATOS) return [];

  var ultimaCol = hoja.getLastColumn();
  var datos = hoja.getRange(FILA_INICIO_DATOS, 1, ultimaFila - FILA_INICIO_DATOS + 1, ultimaCol).getValues();
  var colFC = columnaPorEncabezado(hoja, 'Fecha de cancelación'), colMC = columnaPorEncabezado(hoja, 'Motivo de cancelación');

  var resultado = [];
  for (var i = 0; i < datos.length; i++) {
    var fila = datos[i];
    var contrato = String(fila[COL.CONTRATO - 1] || '').trim();
    var cliente = String(fila[COL.CLIENTE - 1] || '').trim();
    if (!contrato && !cliente) continue; // fila vacía

    resultado.push({
      asesor: String(fila[COL.ASESOR - 1] || ''),
      cedula: String(fila[COL.CEDULA - 1] || ''),
      cliente: cliente,
      fechaFirma: formatoFecha(fila[COL.FECHA - 1]),
      fechaFirmaISO: formatoISO(fila[COL.FECHA - 1]),
      fin: formatoFecha(fila[COL.FIN - 1]),
      finISO: formatoISO(fila[COL.FIN - 1]),
      placa: String(fila[COL.PLACA - 1] || ''),
      contrato: contrato,
      valorProtect: Number(fila[COL.VALOR_PROTECT - 1] || 0),
      valorCuota: Number(fila[COL.VALOR_CUOTA - 1] || 0),
      plazo: Number(fila[COL.PLAZO - 1] || 0),
      forma: String(fila[COL.FORMA - 1] || '').trim().toUpperCase(),
      celular: String(fila[COL.CELULAR - 1] || ''),
      correo: String(fila[COL.CORREO - 1] || ''),
      direccion: String(fila[COL.DIRECCION - 1] || ''),
      edad: Number(fila[COL.EDAD - 1]) || 0,
      fechaNacISO: formatoISO(fila[COL.FECHA_NAC - 1]),
      mes: valorMesAnio(fila[COL.MES - 1], 'mes'),
      anio: valorMesAnio(fila[COL.ANIO - 1], 'anio'),
      comision: Number(fila[COL.COMISION - 1]) || 0,
      rc: String(fila[COL.RC - 1] || '').trim().toUpperCase(),
      ap: String(fila[COL.AP - 1] || '').trim().toUpperCase(),
      estado: String(fila[COL.ESTADO_CLIENTE - 1] || '').trim().toUpperCase(),
      valorCaja: numeroErp_(fila[15]),   // columna P: valor pagado a Dugo Motos (lo que se cobró en caja)
      fechaCancelacionISO: colFC ? formatoISO(fila[colFC - 1]) : '',
      motivoCancelacion: colMC ? String(fila[colMC - 1] || '').trim() : ''
    });
  }
  return resultado;
}

function leerPagos(hoja) {
  if (!hoja) return [];
  var ultimaFila = hoja.getLastRow();
  if (ultimaFila < 2) return [];

  var datos = hoja.getRange(2, 1, ultimaFila - 1, 8).getValues();
  var resultado = [];
  for (var i = 0; i < datos.length; i++) {
    var fila = datos[i];
    var contrato = String(fila[1] || '').trim();
    if (!contrato) continue;
    resultado.push({
      fechaPago: formatoFecha(fila[0]),
      fechaPagoISO: formatoISO(fila[0]),
      contrato: contrato,
      cedula: String(fila[2] || ''),
      cliente: String(fila[3] || ''),
      cuota: String(fila[4] || ''),
      valorPagado: Number(fila[5] || 0),
      nota: String(fila[6] || ''),
      registradoPor: String(fila[7] || '')
    });
  }
  return resultado;
}

function hojaSeguimiento(ss) {
  var hoja = ss.getSheetByName(HOJA_SEGUIMIENTO);
  if (!hoja) {
    throw new Error('No se encontró la pestaña "' + HOJA_SEGUIMIENTO + '". Revisa que se llame exactamente así.');
  }
  return hoja;
}

function formatoFecha(valor) {
  if (!valor) return '';
  var fecha = (valor instanceof Date) ? valor : new Date(valor);
  if (isNaN(fecha.getTime())) return '';
  return ('0' + fecha.getDate()).slice(-2) + '/' + ('0' + (fecha.getMonth() + 1)).slice(-2) + '/' + fecha.getFullYear();
}

// Mes/año tal como están en la hoja; si la celda es una fecha, se devuelve su mes (1-12) o su año.

function valorMesAnio(valor, tipo) {
  if (valor instanceof Date) return String(tipo === 'mes' ? valor.getMonth() + 1 : valor.getFullYear());
  return String(valor === null || valor === undefined ? '' : valor).trim();
}

function formatoISO(valor) {
  if (!valor) return '';
  var fecha = (valor instanceof Date) ? valor : new Date(valor);
  if (isNaN(fecha.getTime())) return '';
  var mes = ('0' + (fecha.getMonth() + 1)).slice(-2);
  var dia = ('0' + fecha.getDate()).slice(-2);
  return fecha.getFullYear() + '-' + mes + '-' + dia;
}


// ==================== COMISIONES: decisiones y observaciones ====================
// Pestaña «Comisiones_Config» (se crea sola): Clave | Valor (JSON) | Actualizado | Registrado por
//   caso:<contrato>            → decisión sobre un caso especial (se paga o no, valor, nota)
//   obs:<AAAA-MM>:<asesor>      → observación escrita en el informe de ese asesor y mes
//   cfg:<nombre>               → ajustes del informe de Kelli (valor por SOAT, etc.)
var HOJA_CONFIG = 'Comisiones_Config';

function hojaConfig(ss) {
  var h = ss.getSheetByName(HOJA_CONFIG);
  if (!h) {
    h = ss.insertSheet(HOJA_CONFIG);
    h.getRange(1, 1, 1, 4).setValues([['Clave', 'Valor', 'Actualizado', 'Registrado por']]).setFontWeight('bold');
    h.setFrozenRows(1);
  }
  return h;
}

function leerConfigComisiones(ss) {
  var h = ss.getSheetByName(HOJA_CONFIG);
  var out = {};
  if (!h || h.getLastRow() < 2) return out;
  var datos = h.getRange(2, 1, h.getLastRow() - 1, 2).getValues();
  for (var i = 0; i < datos.length; i++) {
    var k = String(datos[i][0] || '').trim();
    if (k) out[k] = String(datos[i][1] || '');
  }
  return out;
}

function accionGuardarClave(params) {
  var clave = String(params.clave || '').trim();
  if (!/^(caso|obs|cfg):/.test(clave)) return { ok: false, error: 'Clave no válida.' };
  var valor = String(params.valor === undefined ? '' : params.valor);
  if (valor.length > 2000) return { ok: false, error: 'El texto es demasiado largo.' };
  var lock = LockService.getScriptLock();
  lock.waitLock(20000);
  try {
    var ss = SpreadsheetApp.openById(SHEET_ID);
    var h = hojaConfig(ss);
    var ultima = h.getLastRow(), fila = 0;
    if (ultima >= 2) {
      var claves = h.getRange(2, 1, ultima - 1, 1).getValues();
      for (var i = 0; i < claves.length; i++) { if (String(claves[i][0]).trim() === clave) { fila = i + 2; break; } }
    }
    if (!fila) fila = ultima + 1;
    h.getRange(fila, 1, 1, 4).setValues([[clave, valor, new Date(), String(params.por || '')]]);
    return { ok: true };
  } finally {
    lock.releaseLock();
  }
}


// ==================== HISTÓRICO DE INFORMES DE COMISIONES ====================
// Pestaña «Comisiones_Historico» (se crea sola). Cada guardado agrega una fila nueva (versión 1, 2, 3…): nada se borra.
var HOJA_HIST = 'Comisiones_Historico';
function hojaHistorico(ss) {
  var h = ss.getSheetByName(HOJA_HIST);
  if (!h) {
    h = ss.insertSheet(HOJA_HIST);
    h.getRange(1, 1, 1, 9).setValues([['Clave', 'Mes', 'Año', 'Informe', 'Total a pagar', 'Versión', 'Guardado el', 'Guardado por', 'Datos (no editar)']]).setFontWeight('bold');
    h.setFrozenRows(1);
  }
  return h;
}

function accionGuardarReporte(b) {
  var tipo = String(b.tipo || ''), mes = Number(b.mes), anio = Number(b.anio), total = Number(b.total) || 0;
  if (tipo !== 'general' && tipo !== 'kelli') return { ok: false, error: 'Tipo de informe no válido.' };
  if (!(mes >= 1 && mes <= 12) || !(anio >= 2000 && anio <= 2100)) return { ok: false, error: 'Mes o año no válido.' };
  var datos = String(b.datos || '');
  if (!datos || datos.length > 45000) return { ok: false, error: 'El informe está vacío o es demasiado grande.' };
  var lock = LockService.getScriptLock();
  lock.waitLock(20000);
  try {
    var h = hojaHistorico(SpreadsheetApp.openById(SHEET_ID));
    var clave = anio + '-' + ('0' + mes).slice(-2) + '|' + tipo, version = 1, n = h.getLastRow();
    if (n >= 2) {
      var cl = h.getRange(2, 1, n - 1, 1).getValues();
      for (var i = 0; i < cl.length; i++) if (String(cl[i][0]) === clave) version++;
    }
    h.appendRow([clave, mes, anio, tipo, total, version, new Date(), String(b.por || ''), datos]);
    return { ok: true, version: version };
  } finally { lock.releaseLock(); }
}

function accionListarReportes() {
  var h = SpreadsheetApp.openById(SHEET_ID).getSheetByName(HOJA_HIST), out = [];
  if (!h || h.getLastRow() < 2) return { ok: true, reportes: out };
  var d = h.getRange(2, 1, h.getLastRow() - 1, 8).getValues();
  for (var i = 0; i < d.length; i++) {
    if (!d[i][0]) continue;
    out.push({ fila: i + 2, mes: Number(d[i][1]), anio: Number(d[i][2]), tipo: String(d[i][3]), total: Number(d[i][4]) || 0, version: Number(d[i][5]) || 1,
      guardado: (d[i][6] instanceof Date) ? Utilities.formatDate(d[i][6], Session.getScriptTimeZone(), 'dd/MM/yyyy HH:mm') : String(d[i][6]), por: String(d[i][7]) });
  }
  return { ok: true, reportes: out };
}

function accionVerReporte(p) {
  var fila = Number(p.fila), h = SpreadsheetApp.openById(SHEET_ID).getSheetByName(HOJA_HIST);
  if (!h || !(fila >= 2) || fila > h.getLastRow()) return { ok: false, error: 'No se encontró el informe guardado.' };
  return { ok: true, datos: String(h.getRange(fila, 9).getValue()) };
}


// ==================== COTIZACIONES DE RENOVACIÓN (nuevo, solo agrega) ====================
// Pestaña «Cotizaciones Renovación» (se crea sola). Cada cotización es UNA fila con ID único;
// un mismo cliente puede tener varias. Nunca modifica Protect, Pagos ni ninguna otra pestaña.
var HOJA_COT = 'Cotizaciones Renovación';
var COT_ENC = ['ID cotización','Fecha cotización','Nombre cliente','Cédula','Placa','Marca / Referencia',
  'Valor factura anterior','Valor Fasecolda actual','Valor cotizado contado','Valor cotizado financiado','Plazo (meses)',
  'Estado','Fecha aceptación','Aseguradora','Forma de pago','RC (Sí/No)','AP (Sí/No)','Valor final contratado','Observaciones','Contrato'];
var COT_ESTADOS = ['Pendiente','Aceptó renovación','No aceptó renovación'];

// Hoja de cotizaciones para CLIENTES NUEVOS (no renovaciones): misma estructura, otro nombre y otros títulos en G, H y T.
var HOJA_COT_NUEVA = 'Cotizaciones Clientes Nuevos';
function nombreHojaCot(p) { return (p && String(p.tipo || '') === 'nueva') ? HOJA_COT_NUEVA : HOJA_COT; }
function encabezadosCot(p) {
  var e = COT_ENC.slice();
  if (p && String(p.tipo || '') === 'nueva') { e[6] = 'Valor de la moto'; e[7] = 'Estado de la moto'; e[19] = 'Celular'; }
  return e;
}

function hojaCot(ss, p) {
  var h = ss.getSheetByName(nombreHojaCot(p));
  if (h) return h;
  h = ss.insertSheet(nombreHojaCot(p));
  var ENC = encabezadosCot(p), nueva = !!(p && String(p.tipo || '') === 'nueva');
  var n = ENC.length;
  var enc = h.getRange(1, 1, 1, n);
  enc.setValues([ENC]).setFontWeight('bold').setFontColor('#FFFFFF').setBackground('#0B1F4B')
     .setHorizontalAlignment('center').setVerticalAlignment('middle').setWrap(true);
  h.setRowHeight(1, 42);
  h.setFrozenRows(1);
  h.getRange('B2:B').setNumberFormat('dd/MM/yyyy HH:mm');
  h.getRange('M2:M').setNumberFormat('dd/MM/yyyy HH:mm');
  h.getRange('G2:J').setNumberFormat('"$"#,##0');
  if (nueva) h.getRange('H2:H').setNumberFormat('@');
  h.getRange('R2:R').setNumberFormat('"$"#,##0');
  h.getRange('D2:D').setNumberFormat('@');
  var anchos = [150,120,200,110,90,200,125,125,125,135,80,150,120,120,100,75,75,130,260,110];
  for (var i = 0; i < anchos.length; i++) h.setColumnWidth(i + 1, anchos[i]);
  // Listas desplegables
  h.getRange('L2:L').setDataValidation(SpreadsheetApp.newDataValidation().requireValueInList(COT_ESTADOS, true).setAllowInvalid(false).build());
  h.getRange('N2:N').setDataValidation(SpreadsheetApp.newDataValidation().requireValueInList(['Protect Motos','OMS','Sura'], true).setAllowInvalid(true).build());
  h.getRange('O2:O').setDataValidation(SpreadsheetApp.newDataValidation().requireValueInList(['Contado','Financiado'], true).setAllowInvalid(false).build());
  h.getRange('P2:Q').setDataValidation(SpreadsheetApp.newDataValidation().requireValueInList(['Sí','No'], true).setAllowInvalid(false).build());
  // Colores por estado
  var rg = [h.getRange('L2:L')];
  h.setConditionalFormatRules([
    SpreadsheetApp.newConditionalFormatRule().whenTextEqualTo('Pendiente').setBackground('#FFF3C4').setFontColor('#7A5B00').setRanges(rg).build(),
    SpreadsheetApp.newConditionalFormatRule().whenTextEqualTo('Aceptó renovación').setBackground('#D7F5DF').setFontColor('#0B6B2B').setRanges(rg).build(),
    SpreadsheetApp.newConditionalFormatRule().whenTextEqualTo('No aceptó renovación').setBackground('#FAD4D4').setFontColor('#9B1C1C').setRanges(rg).build()
  ]);
  // Filtro y protección de encabezados (solo advierte: no bloquea a quien edita)
  h.getRange(1, 1, 1, n).createFilter();
  h.getRange(1, 1, 1, n).protect().setDescription('Encabezados de ' + nombreHojaCot(p)).setWarningOnly(true);
  return h;
}

function fechaCotTxt(v) {
  return (v instanceof Date) ? Utilities.formatDate(v, Session.getScriptTimeZone(), 'dd/MM/yyyy HH:mm') : String(v || '');
}

function accionCotRenMoto(p) {
  // Datos de la moto del cliente, tomados de Protect (valor factura = columna AA, marca AB, referencia AC)
  var contrato = String(p.contrato || '').trim();
  if (!contrato) return { ok: false, error: 'Falta el contrato.' };
  var hoja = hojaSeguimiento(SpreadsheetApp.openById(SHEET_ID));
  var ult = hoja.getLastRow();
  if (ult < FILA_INICIO_DATOS) return { ok: true, encontrado: false };
  var datos = hoja.getRange(FILA_INICIO_DATOS, 1, ult - FILA_INICIO_DATOS + 1, 33).getValues();
  for (var i = 0; i < datos.length; i++) {
    var f = datos[i];
    if (String(f[COL.CONTRATO - 1] || '').trim() === contrato) {
      return { ok: true, encontrado: true,
        cliente: String(f[COL.CLIENTE - 1] || ''), cedula: String(f[COL.CEDULA - 1] || ''),
        placa: String(f[COL.PLACA - 1] || ''), celular: String(f[COL.CELULAR - 1] || ''),
        valorMoto: Number(String(f[26] || '').replace(/[^0-9.-]/g, '')) || 0,
        marca: String(f[27] || ''), referencia: String(f[28] || '') };
    }
  }
  return { ok: true, encontrado: false };
}

function accionCotRenListar(p) {
  var h = SpreadsheetApp.openById(SHEET_ID).getSheetByName(nombreHojaCot(p)), out = [];
  if (!h || h.getLastRow() < 2) return { ok: true, cotizaciones: out };
  var d = h.getRange(2, 1, h.getLastRow() - 1, COT_ENC.length).getValues();
  for (var i = 0; i < d.length; i++) {
    if (!d[i][0]) continue;
    out.push({ id: String(d[i][0]), fecha: fechaCotTxt(d[i][1]), nombre: String(d[i][2]), cedula: String(d[i][3]), placa: String(d[i][4]),
      moto: String(d[i][5]), factura: Number(d[i][6]) || 0, fasecolda: Number(d[i][7]) || 0, contado: Number(d[i][8]) || 0,
      financiado: Number(d[i][9]) || 0, plazo: Number(d[i][10]) || 0, estado: String(d[i][11]), fechaAcep: fechaCotTxt(d[i][12]),
      aseguradora: String(d[i][13]), forma: String(d[i][14]), rc: String(d[i][15]), ap: String(d[i][16]),
      valorFinal: Number(d[i][17]) || 0, obs: String(d[i][18]), contrato: String(d[i][19]) });
  }
  return { ok: true, cotizaciones: out };
}

function accionCotRenGuardar(p) {
  var nombre = String(p.nombre || '').trim();
  if (!nombre) return { ok: false, error: 'Falta el nombre del cliente.' };
  var lock = LockService.getScriptLock();
  lock.waitLock(20000);
  try {
    var h = hojaCot(SpreadsheetApp.openById(SHEET_ID), p), nueva = String(p.tipo || '') === 'nueva';
    var ahora = new Date(), tz = Session.getScriptTimeZone();
    var pref = (nueva ? 'CTZ-' : 'COT-') + Utilities.formatDate(ahora, tz, 'yyyyMMdd') + '-';
    var n = h.getLastRow(), seq = 1;
    if (n >= 2) {
      var ids = h.getRange(2, 1, n - 1, 1).getValues();
      for (var i = 0; i < ids.length; i++) {
        var id = String(ids[i][0]);
        if (id.indexOf(pref) === 0) { var k = parseInt(id.slice(pref.length), 10) || 0; if (k >= seq) seq = k + 1; }
      }
    }
    var id2 = pref + ('00' + seq).slice(-3);
    var num = function (v) { return Number(String(v || '').replace(/[^0-9.-]/g, '')) || 0; };
    var fila = n + 1;
    h.getRange(fila, 1, 1, COT_ENC.length).setValues([[id2, ahora, nombre, "'" + String(p.cedula || ''), String(p.placa || ''),
      String(p.moto || ''), num(p.factura), (nueva ? String(p.estadoMoto || '') : num(p.fasecolda)), num(p.contado), num(p.financiado), num(p.plazo),
      'Pendiente', '', '', '', '', '', '', String(p.obs || '').slice(0, 900), String(p.contrato || '')]]);
    h.getRange(fila, 4).setNumberFormat('@').setValue(String(p.cedula || ''));
    return { ok: true, id: id2 };
  } finally { lock.releaseLock(); }
}

function accionCotRenEstado(p) {
  var id = String(p.id || '').trim(), estado = String(p.estado || '').trim();
  if (COT_ESTADOS.indexOf(estado) < 0) return { ok: false, error: 'Estado no válido.' };
  var lock = LockService.getScriptLock();
  lock.waitLock(20000);
  try {
    var h = SpreadsheetApp.openById(SHEET_ID).getSheetByName(nombreHojaCot(p));
    if (!h || h.getLastRow() < 2) return { ok: false, error: 'No hay cotizaciones guardadas.' };
    var ids = h.getRange(2, 1, h.getLastRow() - 1, 1).getValues(), fila = 0;
    for (var i = 0; i < ids.length; i++) if (String(ids[i][0]) === id) { fila = i + 2; break; }
    if (!fila) return { ok: false, error: 'No se encontró la cotización ' + id + '.' };
    var num = function (v) { return Number(String(v || '').replace(/[^0-9.-]/g, '')) || 0; };
    h.getRange(fila, 12).setValue(estado);
    if (estado === 'Aceptó renovación') {
      h.getRange(fila, 13, 1, 7).setValues([[new Date(), String(p.aseguradora || ''), String(p.forma || ''),
        String(p.rc || ''), String(p.ap || ''), num(p.valorFinal), String(p.obs || '')]]);
      if (num(p.plazo) > 0) h.getRange(fila, 11).setValue(num(p.plazo));
    } else if (estado === 'No aceptó renovación') {
      h.getRange(fila, 13).setValue(new Date());
      h.getRange(fila, 19).setValue(String(p.obs || ''));
    } else {
      h.getRange(fila, 13).clearContent();
    }
    return { ok: true, id: id, estado: estado };
  } finally { lock.releaseLock(); }
}


// ==================== RENOVACIONES: gestiones para el Inicio (nuevo, solo lee) ====================
// Devuelve de la hoja «Gestiones» únicamente las filas de renovación (mensaje enviado, aceptada, no aceptada, vencida, seguimientos).
function accionRenovGestiones() {
  var h = SpreadsheetApp.openById(SHEET_ID).getSheetByName('Gestiones'), out = [];
  if (!h || h.getLastRow() < 2) return { ok: true, gestiones: out };
  var d = h.getRange(2, 1, h.getLastRow() - 1, 6).getValues();
  for (var i = 0; i < d.length; i++) {
    var acc = String(d[i][4] || '');
    if (!/renovaci/i.test(acc)) continue;
    var contrato = String(d[i][1] || '').trim();
    if (!contrato) continue;
    out.push({ fechaISO: formatoISO(d[i][0]), contrato: contrato, cliente: String(d[i][3] || ''), accion: acc });
  }
  return { ok: true, gestiones: out };
}


// ==================== CRUCE SEMANAL ERP: lectura de Protect para el cruce semanal (nuevo, SOLO LEE) ====================
// Devuelve, por cada fila de la hoja Protect: fila, asesor, cédula, cliente, placa, contrato, valor de la columna P y estado.
// No escribe nada y no modifica ninguna hoja.
function numeroErp_(v) {
  if (typeof v === 'number') return isNaN(v) ? null : v;
  var t = String(v === null || v === undefined ? '' : v).replace(/[$\s]/g, '');
  if (!t) return null;
  if (/^-?\d{1,3}(\.\d{3})+(,\d+)?$/.test(t)) t = t.replace(/\./g, '').replace(',', '.');
  else if (/^-?\d{1,3}(,\d{3})+(\.\d+)?$/.test(t)) t = t.replace(/,/g, '');
  else t = t.replace(',', '.');
  var n = Number(t);
  return isNaN(n) ? null : n;
}

function accionErpProtect() {
  var hoja = hojaSeguimiento(SpreadsheetApp.openById(SHEET_ID));
  var ult = hoja.getLastRow(), out = [];
  var ancho = Math.min(Math.max(hoja.getLastColumn(), 16), 44);
  var encP = '';
  try {
    var t = hoja.getRange(1, 16, 2, 1).getDisplayValues();
    encP = String(t[1][0] || t[0][0] || '');
  } catch (e) {}
  if (ult < 2) return { ok: true, filas: out, encabezadoP: encP };
  var datos = hoja.getRange(2, 1, ult - 1, ancho).getValues();
  for (var i = 0; i < datos.length; i++) {
    var f = datos[i];
    var ced = String(f[4] === null || f[4] === undefined ? '' : f[4]).trim();
    var cli = String(f[7] || '').trim();
    var ctr = String(f[13] || '').trim();
    if (!/\d/.test(ced) && !cli && !ctr) continue;
    if (!/\d/.test(ced)) continue;          // fila de títulos o sin cédula
    out.push({ fila: i + 2, asesor: String(f[1] || '').trim(), cedula: ced, cliente: cli, placa: String(f[12] || '').trim(),
      contrato: ctr, valorP: numeroErp_(f[15]), estado: ancho >= 44 ? String(f[43] || '').trim().toUpperCase() : '' });
  }
  return { ok: true, filas: out, encabezadoP: encP };
}


// ==================== VERIFICACIÓN BANCARIA: lee la hoja de movimientos del banco (nuevo, SOLO LEE) ====================
// Abre el Google Sheet del banco por su ID (la cuenta que publicó el script debe tener acceso) y devuelve sus filas tal cual
// (las fechas como texto aaaa-mm-dd). El sistema detecta solo las columnas de fecha, valor y descripción. No escribe nada.
// Hoja de Google con los movimientos del banco («Consolidado todas las consignaciones»). Si algún día cambia de hoja,
// cambie este ID (lo que está entre /d/ y /edit en el enlace de la hoja) y publique una Nueva versión.
var BANCO_SHEET_ID = '1RX0Af2Q8dB99JxrvpxDf1Ru23rA0ktbsQA2RLlaNbSg';
var BANCO_HOJA = '';    // nombre de la pestaña; vacío = la primera

function accionBancoLeer(p) {
  var id = String(p.sheetId || BANCO_SHEET_ID || '').trim();
  if (!/^[A-Za-z0-9_-]{20,}$/.test(id)) return { ok: false, error: 'Falta el ID de la hoja del banco en el código (BANCO_SHEET_ID) o no es válido.' };
  var ss;
  try { ss = SpreadsheetApp.openById(id); } catch (e) { return { ok: false, error: 'No pude abrir la hoja del banco. Revise el enlace y que esté en la misma cuenta de Google donde publicó el script. Si junto al nombre del archivo en Google dice «.XLSX», es un Excel y no una hoja de Google: ábralo y use Archivo → Guardar como hoja de cálculo de Google, y pegue el enlace de la copia nueva.' }; }
  var nombreHoja = String(p.hoja || BANCO_HOJA || '').trim();
  var hoja = nombreHoja ? ss.getSheetByName(nombreHoja) : ss.getSheets()[0];
  var pestanas = ss.getSheets().map(function (x) { return x.getName(); });
  if (!hoja) return { ok: false, error: 'No encontré la pestaña «' + nombreHoja + '». Las pestañas de esa hoja son: ' + pestanas.join(', ') + '.' };
  var ult = hoja.getLastRow(), anc = Math.min(Math.max(hoja.getLastColumn(), 1), 20);
  var max = Math.min(Math.max(Number(p.max) || 8000, 100), 20000), tz = Session.getScriptTimeZone();
  var conv = function (fila) { return fila.map(function (v) { return (v instanceof Date) ? Utilities.formatDate(v, tz, 'yyyy-MM-dd') : v; }); };
  var filas = [], recortado = false;
  if (ult < 1) return { ok: true, nombre: ss.getName(), hoja: hoja.getName(), pestanas: pestanas, filas: [], recortado: false, totalFilas: 0 };
  if (ult <= max) {
    filas = hoja.getRange(1, 1, ult, anc).getValues().map(conv);
  } else {   // hoja muy larga: las primeras 40 filas (títulos) y las últimas
    recortado = true;
    filas = hoja.getRange(1, 1, 40, anc).getValues().map(conv).concat(hoja.getRange(ult - (max - 40) + 1, 1, max - 40, anc).getValues().map(conv));
  }
  return { ok: true, nombre: ss.getName(), hoja: hoja.getName(), pestanas: pestanas, filas: filas, recortado: recortado, totalFilas: ult, desdeCola: recortado ? (ult - (max - 40) + 1) : 0 };
}

/* Escribe el nombre del cliente al frente de cada consignación en la hoja del banco.
   Solo escribe en celdas VACÍAS (nunca pisa lo que usted ya anotó) y solo en la columna indicada. */
function accionBancoAnotar(p) {
  var id = String(p.sheetId || BANCO_SHEET_ID || '').trim();
  if (!/^[A-Za-z0-9_-]{20,}$/.test(id)) return { ok: false, error: 'Falta el ID de la hoja del banco.' };
  var items;
  try { items = JSON.parse(p.items || '[]'); } catch (e) { return { ok: false, error: 'Lista de nombres inválida.' }; }
  if (!items.length) return { ok: true, escritas: 0, omitidas: 0 };
  if (items.length > 600) return { ok: false, error: 'Demasiados movimientos de una vez (máximo 600).' };
  var col = Math.max(1, Math.min(Number(p.col) || 7, 40));
  var ss;
  try { ss = SpreadsheetApp.openById(id); } catch (e) { return { ok: false, error: 'No pude abrir la hoja del banco.' }; }
  var nombreHoja = String(p.hoja || BANCO_HOJA || '').trim();
  var hoja = nombreHoja ? ss.getSheetByName(nombreHoja) : ss.getSheets()[0];
  if (!hoja) return { ok: false, error: 'No encontré la pestaña del banco.' };
  var esc = 0, omit = 0;
  var hdrFila = Number(p.hdrFila) || 0;
  if (hdrFila > 0 && p.hdr && String(hoja.getRange(hdrFila, col).getValue() || '').trim() === '') hoja.getRange(hdrFila, col).setValue(String(p.hdr));
  items.forEach(function (it) {
    var f = Number(it.fila), nom = String(it.cliente || '').trim();
    if (!(f > 0) || !nom) { omit++; return; }
    var cel = hoja.getRange(f, col);
    if (String(cel.getValue() || '').trim() !== '') { omit++; return; }
    cel.setValue(nom); esc++;
  });
  SpreadsheetApp.flush();
  return { ok: true, escritas: esc, omitidas: omit };
}


/* ===== Cuentas con Seguros Mundial: lee la hoja «Estado de Facturas» (solo lectura) =====
   Se lee todo lo que haya (hasta 20 columnas); el sistema ubica cada dato por el título de su columna. */
var MUNDIAL_SHEET_ID = '1G1pHHVPcRVaJ_qqm1bYZBk2Yl1QpIfnVSWmHIUV1te4';   // ID de la hoja «Estado de Facturas» (lo que va entre /d/ y /edit en su enlace); también se puede pegar en el módulo
var MUNDIAL_HOJA = '';       // nombre de la pestaña; vacío = la primera
function accionMundialLeer(p) {
  var id = String(p.sheetId || MUNDIAL_SHEET_ID || '').trim();
  if (!/^[A-Za-z0-9_-]{20,}$/.test(id)) return { ok: false, error: 'Falta el ID de la hoja «Estado de Facturas». Péguelo en el módulo «Facturación Mundial» o en MUNDIAL_SHEET_ID dentro del código.' };
  var ss;
  try { ss = SpreadsheetApp.openById(id); } catch (e) { return { ok: false, error: 'No pude abrir la hoja de facturas. Revise el enlace y que esté en la misma cuenta de Google donde publicó el script.' }; }
  var nombreHoja = String(p.hoja || MUNDIAL_HOJA || '').trim();
  var hoja = nombreHoja ? ss.getSheetByName(nombreHoja) : ss.getSheets()[0];
  var pestanas = ss.getSheets().map(function (x) { return x.getName(); });
  if (!hoja) return { ok: false, error: 'No encontré la pestaña «' + nombreHoja + '». Las pestañas son: ' + pestanas.join(', ') + '.' };
  var ult = hoja.getLastRow(), anc = Math.min(Math.max(hoja.getLastColumn(), 1), 20), tz = Session.getScriptTimeZone();
  if (ult < 1) return { ok: true, nombre: ss.getName(), hoja: hoja.getName(), pestanas: pestanas, filas: [] };
  var max = Math.min(ult, 20000);
  var filas = hoja.getRange(1, 1, max, anc).getValues().map(function (f) {
    return f.map(function (v) { return (v instanceof Date) ? Utilities.formatDate(v, tz, 'yyyy-MM-dd') : v; });
  });
  return { ok: true, nombre: ss.getName(), hoja: hoja.getName(), pestanas: pestanas, filas: filas, totalFilas: ult };
}


/* ===== Facturación Mundial: registrar y corregir cobros en «Estado de Facturas» =====
   Cada dato se escribe en la columna que tenga ese TÍTULO en la fila 1 (así sigue funcionando si se insertan columnas, como «# factura Retorno»).
   Solo toca la fila que se guarda; nunca borra filas. Las únicas pólizas válidas son estas tres; el producto sale de la póliza. */
var MUNDIAL_POLIZAS = { '2000725842': 'AP', '2000722986': 'RC', '2000743946': 'VG' };
function mundialColumnas_(hoja) {
  var ult = Math.max(hoja.getLastColumn(), 1), enc = hoja.getRange(1, 1, 1, ult).getValues()[0];
  var n = function (t) { return String(t == null ? '' : t).normalize('NFD').replace(/[̀-ͯ]/g, '').toLowerCase().replace(/\s+/g, ' ').trim(); };
  var c = {};
  enc.forEach(function (t, j) {
    var h = n(t); if (!h) return;
    if (/factura/.test(h) && /retorno/.test(h)) c.facRet = j;
    else if (/factura/.test(h) && c.fac == null) c.fac = j;
    else if (/periodo.*desde/.test(h)) c.desde = j;
    else if (/periodo.*hasta/.test(h)) c.hasta = j;
    else if (/radicad/.test(h) && /home/.test(h)) c.radHome = j;
    else if (/radicad/.test(h) && /(correo|rc)/.test(h)) c.radCorreo = j;
    else if (/^#?\s*cobro/.test(h)) c.cobro = j;
    else if (/^#?\s*poliza/.test(h)) c.poliza = j;
    else if (/^producto/.test(h)) c.producto = j;
    else if (/^valor cobrado/.test(h)) c.valor = j;
    else if (/prima base/.test(h)) c.prima = j;
    else if (/retorno/.test(h)) c.retorno = j;
    else if (/^%/.test(h)) c.pct = j;
    else if (/^estado/.test(h)) c.estado = j;
    else if (/fecha limite/.test(h)) c.limite = j;
    else if (/observ/.test(h)) c.obs = j;
  });
  return { c: c, ancho: ult };
}
function accionMundialGuardar(p) {
  var id = String(p.sheetId || MUNDIAL_SHEET_ID || '').trim();
  if (!/^[A-Za-z0-9_-]{20,}$/.test(id)) return { ok: false, error: 'Falta el ID de la hoja «Estado de Facturas».' };
  var d;
  try { d = JSON.parse(p.datos || '{}'); } catch (e) { return { ok: false, error: 'Datos inválidos.' }; }
  var pol = String(d.poliza || '').replace(/\D/g, '');
  if (!MUNDIAL_POLIZAS[pol]) return { ok: false, error: 'La póliza debe ser una de estas: 2000725842 (AP), 2000722986 (RC) o 2000743946 (VG).' };
  var fac = String(d.factura || '').trim();
  if (!fac) return { ok: false, error: 'Falta el número de factura.' };
  var lock = LockService.getScriptLock();
  if (!lock.tryLock(15000)) return { ok: false, error: 'El sistema está ocupado, intente de nuevo en unos segundos.' };
  try {
    var ss; try { ss = SpreadsheetApp.openById(id); } catch (e) { return { ok: false, error: 'No pude abrir la hoja de facturas.' }; }
    var nombreHoja = String(p.hoja || MUNDIAL_HOJA || '').trim();
    var hoja = nombreHoja ? ss.getSheetByName(nombreHoja) : ss.getSheets()[0];
    if (!hoja) return { ok: false, error: 'No encontré la pestaña de facturas.' };
    var mp = mundialColumnas_(hoja), C = mp.c, falta = [];
    ['fac', 'poliza', 'producto', 'valor', 'retorno', 'estado'].forEach(function (k) { if (C[k] == null) falta.push(k); });
    if (falta.length) return { ok: false, error: 'No encuentro en la fila 1 de la hoja las columnas: ' + falta.join(', ') + '. No escribo para no dañar la hoja.' };
    var fecha = function (t) { var m = /^(\d{4})-(\d{2})-(\d{2})$/.exec(String(t || '')); return m ? new Date(Number(m[1]), Number(m[2]) - 1, Number(m[3])) : ''; };
    var nro = function (t) { if (t === '' || t == null) return ''; var n = Number(String(t).replace(/[^0-9.\-]/g, '')); return isNaN(n) ? '' : n; };
    // Regla de retorno NG sobre la prima base: RC 3,75 % · AP 10 % · VG sin retorno.
    var REGLA = { '2000722986': 3.75, '2000725842': 10 }, prima0 = nro(d.prima), ret0 = nro(d.retorno), pct0 = nro(d.pct);
    if (pol === '2000743946') { ret0 = ''; pct0 = ''; }
    else if (REGLA[pol]) { if (pct0 === '') pct0 = REGLA[pol]; if (ret0 === '' && prima0 !== '') ret0 = Math.round(prima0 * pct0 / 100); }
    else if (pct0 === '' && prima0 && ret0 !== '') pct0 = Math.round(ret0 / prima0 * 10000) / 100;
    var valores = { fac: fac, desde: fecha(d.desde), hasta: fecha(d.hasta), radHome: String(d.radHome || '').trim(), radCorreo: String(d.radCorreo || '').trim(), cobro: nro(d.cobro),
      poliza: Number(pol), producto: MUNDIAL_POLIZAS[pol], valor: nro(d.valor), prima: prima0, facRet: String(d.facRet || '').trim(), retorno: ret0, pct: pct0,
      estado: String(d.estado || '').trim(), limite: fecha(d.limite), obs: String(d.obs || '').trim() };
    var ult = hoja.getLastRow(), colFac = ult > 1 ? hoja.getRange(1, C.fac + 1, ult, 1).getValues() : [[]], colPol = ult > 1 ? hoja.getRange(1, C.poliza + 1, ult, 1).getValues() : [[]];
    var colCob = (C.cobro != null && ult > 1) ? hoja.getRange(1, C.cobro + 1, ult, 1).getValues() : null;
    var objetivo, nueva = (String(p.modo) !== 'editar');
    if (nueva) {
      for (var i = 1; i < colFac.length; i++) {
        if (String(colFac[i][0]).trim() === fac && String(colPol[i][0]).replace(/\D/g, '') === pol) {
          if (colCob && String(colCob[i][0]) === String(valores.cobro) && !String(p.forzar || '')) return { ok: false, duplicado: true, error: 'Ya existe esta factura con esta póliza y este # de cobro (fila ' + (i + 1) + '). Si es otro cobro, cambie el # de cobro.' };
        }
      }
      var ultima = 1; for (var j = 1; j < colFac.length; j++) { if (String(colFac[j][0]).trim() !== '' || String(colPol[j][0]).trim() !== '') ultima = j + 1; }
      objetivo = ultima + 1;
    } else {
      objetivo = Number(p.fila);
      if (!(objetivo > 1) || objetivo > ult) return { ok: false, error: 'La fila a corregir no es válida.' };
      var esp = String(p.esperada || '');
      var actual = String(colFac[objetivo - 1][0]).trim() + '|' + String(colPol[objetivo - 1][0]).replace(/\D/g, '');
      if (esp && actual !== esp) return { ok: false, error: 'La hoja cambió: la fila ' + objetivo + ' ya no es la misma (ahora dice ' + actual + '). Vuelva a leer la hoja y repita la corrección.' };
    }
    // se parte de lo que ya hay en la fila (para no borrar columnas que este formulario no maneja) y se escriben solo las columnas conocidas
    var fila = nueva ? new Array(mp.ancho).fill('') : hoja.getRange(objetivo, 1, 1, mp.ancho).getValues()[0];
    Object.keys(valores).forEach(function (k) { if (C[k] != null) fila[C[k]] = valores[k]; });
    hoja.getRange(objetivo, 1, 1, mp.ancho).setValues([fila]);
    ['desde', 'hasta', 'limite'].forEach(function (k) { if (C[k] != null) hoja.getRange(objetivo, C[k] + 1).setNumberFormat('d/m/yyyy'); });
    ['valor', 'prima', 'retorno'].forEach(function (k) { if (C[k] != null) hoja.getRange(objetivo, C[k] + 1).setNumberFormat('$ #,##0'); });
    SpreadsheetApp.flush();
    return { ok: true, fila: objetivo, nueva: nueva };
  } finally { lock.releaseLock(); }
}
